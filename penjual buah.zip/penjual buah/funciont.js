const products = [
    {
        id: "1",
        fruit: "Apple",
        size: "Big",
        color: "Red",
        price: 5000,
        status: true,
        image: "images/apel.jpg"
    },
    {
        id: "2",
        fruit: "Mango",
        size: "Medium",
        color: "Green",
        price: 10000,
        status: false,
        image: "images/manga.jpg"
    },
    {
        id: "3",
        fruit: "Grape",
        size: "Small",
        color: "Black",
        price: 1500,
        status: true,
        image: "images/anggur.jpg"
    },
    {
        id: "4",
        fruit: "Pineapple",
        size: "Big",
        color: "Yellow",
        price: 20000,
        status: false,
        image: "images/nanas.jpg"
    },
    {
        id: "5",
        fruit: "Orange",
        size: "Small",
        color: "Orange",
        price: 7500,
        status: true,
        image: "images/jeruk.jpg"
    },
    {
        id: "6",
        fruit: "Dragon Fruit",
        size: "Medium",
        color: "Red",
        price: 8000,
        status: true,
        image: "images/Buah Naga.jpg"
    },
    {
        id: "7",
        fruit: "Guava",
        size: "Small",
        color: "Green",
        price: 3000,
        status: false,
        image: "images/jambu.jpg"
    },
    {
        id: "8",
        fruit: "Blueberry",
        size: "Small",
        color: "Blue",
        price: 3500,
        status: true,
        image: "images/bluebery.jpg"
    },
    {
        id: "9",
        fruit: "Lemon",
        size: "Medium",
        color: "Yellow",
        price: 15000,
        status: true,
        image: "images/lemon.jpg"
    },
    {
        id: "10",
        fruit: "Banana",
        size: "Medium",
        color: "Yellow",
        price: 25000,
        status: true,
        image: "images/pisang.jpg"
    }
  ];
    

  let cart = JSON.parse(localStorage.getItem('cart')) || [];
  let filteredProducts = [...products];

  function getCardColor(color) {
    switch (color.toLowerCase()) {
      case 'red':
        return 'bg-red-100';
      case 'green':
        return 'bg-green-100';
      case 'black':
        return 'bg-black-100';
      case 'yellow':
        return 'bg-yellow-100';
      case 'orange':
        return 'bg-orange-100';
      case 'blue':
        return 'bg-blue-100';
      default:
        return 'bg-white';
    }
  }
  
  // Menampilkan produk
  function renderProducts(productsToRender) {
    const productContainer = document.getElementById("product-list");
    productContainer.innerHTML = "";
    productsToRender.forEach((product) => {
      const statusText = product.status ? "Available" : "Not Available";
      const statusClass = product.status ? "text-green-500 font-bold" : "text-red-500 font-bold";
      const cardColor = getCardColor(product.color);
  
      productContainer.innerHTML += `
        <div class="${cardColor} shadow-md rounded-lg overflow-hidden">
          <img src="${product.image}" alt="${product.fruit}" class="w-full h-48 object-cover transition delay-150 duration-300 ease-in-out hover:-translate-y-1 hover:scale-110" onclick="openProductPage('${product.id}')">
          <div class="p-4">
            <h4 class="text-lg font-semibold text-green-700">${product.fruit}</h4>
            <p class="text-black-600 mt-2 font-bold">Size: ${product.size}</p>
            <p class="text-black-600 mt-2 font-bold">Color: ${product.color}</p>
            <p class="text-black-600 mt-2 font-bold">Price: Rp ${product.price.toLocaleString()} / kg</p>
            <p>Status: <span class="${statusClass}">${statusText}</span></p>
            <button 
              onclick="addToCart('${product.id}')" 
              class="bg-green-500 text-white px-4 py-2 mt-4 w-full rounded-lg hover:bg-green-600" 
              s>
              Add To Cart
            </button>
          </div>
        </div>`;
    });
  }
  
  function openProductPage(productId) {
    window.location.href = `articel.html?id=${encodeURIComponent(productId)}`;
  }


  function applyFiltersAndSort() {
    let result = [...products];
  
    const searchInput = document.getElementById("search").value.toLowerCase();
    if (searchInput) {
      result = result.filter(product => product.fruit.toLowerCase().includes(searchInput));
    }
  
    const selectedSize = document.getElementById("filter").value;
    if (selectedSize && selectedSize !== "all") {
      result = result.filter(product => product.size.toLowerCase() === selectedSize.toLowerCase());
    }
  
    const sortSelect = document.getElementById("sort");
    if (sortSelect) {
      const sortType = sortSelect.value;
      switch (sortType) {
        case "name-a-z":
          result.sort((a, b) => a.fruit.localeCompare(b.fruit));
          break;
        case "price-low-high":
          result.sort((a, b) => a.price - b.price);
          break;
        case "price-high-low":
          result.sort((a, b) => b.price - a.price);
          break;
      }
    }
  
    const productContainer = document.getElementById("product-list");
    if (result.length === 0) {
      productContainer.innerHTML = `<p class="text-red-500 font-bold text-3xl">No products found.</p>`;
    } else {
      renderProducts(result);
    }
    setTimeout(() => {
      document.getElementById("buah").scrollIntoView({ behavior: "smooth" });
    }, 300);
  }

  
  function handleSearch() {
    applyFiltersAndSort();
  }
  
  function handleSort() {
    applyFiltersAndSort();
  }
  
  function handleFilter() {
    applyFiltersAndSort();
  }
  function addToCart(productId) {

    console.log(`Mencoba menambahkan produk dengan ID: ${productId}`); 
    const product = products.find(p => p.id === productId);
    if (!product.status) {
           alert(`Sorry, ${product.fruit}  Currently Unavailable.`);
      return;
    }
    else if (product.status) {
      alert(`${product.fruit} Have Been Add To Cart.`);
    }
    const existingItem = cart.find(item => item.fruit === product.fruit);
    if (existingItem) {
      existingItem.quantity += 1; 
    } else {
      cart.push({ ...product, quantity: 1 }); 
    }
    updateCartCount(); 
    

    localStorage.setItem('cart', JSON.stringify(cart)); 
    //alert ini tidak muncul tidak tau kenapa 
  //   if (product.status) {
  //     alert(`${product.fruit} Have Been Add To Cart.`);
      
  //   }else{
  //     alert(`Sorry, ${product.fruit}  Currently Unavailable.`);
  //     console.log('tes');
  // }
  
}
  
  function updateCartCount() {
    const cartCount = cart.length;
    document.getElementById("cart-count").innerText = cartCount;
  }
  
  document.addEventListener("DOMContentLoaded", () => {
    renderProducts(products);
    updateCartCount(); 
  });