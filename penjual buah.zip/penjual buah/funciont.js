let products = [
    { name: "Apel Merah", price: 25000, image: "images/apel.jpg"     },
    { name: "Anggur Merah", price: 30000, image: "images/anggur.jpg" },
    { name: "Jeruk", price: 30000, image: "images/jeruk.jpg" },
    { name: "Pisang", price: 20000, image: "images/pisang.jpg" },
    { name: "Semangka", price: 30000, image: "images/semangka.jpg" },
    { name: "Kiwi", price: 20000, image: "images/kiwi.jpg" },
    { name: "Nanas", price: 25000, image: "images/nanas.jpg" },
    { name: "Lemon", price: 20000, image: "images/lemon.jpg" },
    { name: "Buah Naga", price: 20000, image: "images/Buah Naga.jpg" },
    { name: "Pisang", price: 20000, image: "images/pisang.jpg" },
  ];

  let cart = [];

  function renderProducts(filteredProducts) {
    const productContainer = document.getElementById("product-list");
    productContainer.innerHTML = "";
    filteredProducts.forEach((product, index) => {
      productContainer.innerHTML += `
        <div class="bg-white shadow-md rounded-lg overflow-hidden">
          <img src="${product.image}" alt="${product.name}" class="w-full h-48 object-cover">
          <div class="p-4">
            <h4 class="text-lg font-semibold text-green-700">${product.name}</h4>
            <p class="text-gray-600 mt-2">Rp ${product.price.toLocaleString()} / kg</p>
            <button 
              onclick="addToCart(${index})" 
              class="bg-green-500 text-white px-4 py-2 mt-4 w-full rounded-lg hover:bg-green-600">
              Tambahkan ke Keranjang
            </button>
          </div>
        </div>`;
    });
  }

  function addToCart(index) {
    const product = products[index];
    const existingProduct = cart.find(item => item.name === product.name);
    if (existingProduct) {
      existingProduct.quantity += 1;
    } else {
      cart.push({ ...product, quantity: 1 });
    }
    renderCart();
  }

  function renderCart() {
    const cartContainer = document.getElementById("cart-list");
    const cartTotal = document.getElementById("cart-total");
    cartContainer.innerHTML = "";
    let total = 0;
    cart.forEach((item, index) => {
      total += item.price * item.quantity;
      cartContainer.innerHTML += `
        <div class="flex justify-between items-center border-b py-2">
          <span>${item.name} (x${item.quantity})</span>
          <span>Rp ${(item.price * item.quantity).toLocaleString()}</span>
          <button 
            onclick="removeFromCart(${index})" 
            class="text-red-500 hover:underline">
            Hapus
          </button>
        </div>`;
    });
    cartTotal.textContent = `Total: Rp ${total.toLocaleString()}`;
  }

  function removeFromCart(index) {
    cart.splice(index, 1);
    renderCart();
  }

  function handleSearch() {
    const searchInput = document.getElementById("search").value.toLowerCase();
    const filteredProducts = products.filter(product => product.name.toLowerCase().includes(searchInput));
    renderProducts(filteredProducts);
  }

  function handleSort(option) {
    let sortedProducts;
    if (option === "name-a-z") {
      sortedProducts = [...products].sort((a, b) => a.name.localeCompare(b.name));
    } else if (option === "price-low-high") {
      sortedProducts = [...products].sort((a, b) => a.price - b.price);
    } else if (option === "price-high-low") {
      sortedProducts = [...products].sort((a, b) => b.price - a.price);
    }
    renderProducts(sortedProducts);
  }

  document.addEventListener("DOMContentLoaded", () => {
    renderProducts(products);
    renderCart();
  });