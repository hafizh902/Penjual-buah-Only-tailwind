let cart = JSON.parse(localStorage.getItem('cart')) || [];


function addToCart(product) {
    if (!product.status) {
        alert(`${product.fruit} is not available for purchase.`);
        return;
    }

    
    const existingItem = cart.find(item => item.fruit === product.fruit);
    if (existingItem) {
        existingItem.quantity += 1; 
    } else {
        cart.push({ ...product, quantity: 1 }); 
    }
    
    localStorage.setItem('cart', JSON.stringify(cart));
    alert(`${product.fruit} has been added to your cart.`);
    updateCartCount(); 
}

function updateCartCount() {
    const cartCount = cart.length;
    document.getElementById("cart-count").innerText = cartCount;
}

function renderCart() {
    const cartList = document.getElementById('cart-list');
    const cartTotal = document.getElementById('cart-total');
    cartList.innerHTML = ''; 
    let total = 0;

    cart.forEach(item => {
        const itemDiv = document.createElement('div');
        itemDiv.classList.add('flex', 'justify-between', 'items-center', 'py-2', 'border-b');
        itemDiv.innerHTML = `
            <span>${item.fruit} (x${item.quantity})</span>
            <span>Rp ${(item.price * item.quantity).toLocaleString()}</span>
            <button onclick="removeFromCart('${item.fruit}')" class="text-red-500 hover:underline">Remove</button>
        `;
        cartList.appendChild(itemDiv);
        total += item.price * item.quantity;
    });

    cartTotal.innerHTML = `Total: Rp ${total.toLocaleString()}`;
}


function removeFromCart(fruitName) {
    cart = cart.filter(item => item.fruit !== fruitName);
    localStorage.setItem('cart', JSON.stringify(cart)); 
    renderCart();
}

// Function to handle checkout
function checkout() {
    if (cart.length === 0) {
        alert("Your cart is empty.");
        return;
    }

    // Here you can implement further checkout logic (e.g., payment processing)
    alert("Thank you for your purchase! Your order has been placed.");
    
    // Clear the cart after checkout
    cart = [];
    localStorage.removeItem('cart'); // Clear cart from localStorage
    renderCart(); // Update display
}


document.addEventListener('DOMContentLoaded', () => {
    renderCart(); 
    updateCartCount(); 
});

